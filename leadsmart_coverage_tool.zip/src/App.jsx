import React, { useState, useEffect } from 'react';
import { 
  Search, ShieldCheck, Flame, Droplets, Wrench, Home, Sun, 
  Layers, Hammer, Umbrella, Bug, Paintbrush, Wind, Zap, 
  HelpCircle, ChevronDown, ChevronUp, Download, ArrowUpRight, 
  CheckCircle, Bookmark, BookmarkCheck, TrendingUp, DollarSign,
  Building, RefreshCw
} from 'lucide-react';

const STATIC_NICHES = [
  {"niche": "Biohazard cleanup", "model": "Cost per lead", "zipCount": 11290, "median": 224.50, "min": 179.00, "max": 319.00},
  {"niche": "Fire damage removal", "model": "Cost per lead", "zipCount": 17477, "median": 199.00, "min": 110.00, "max": 365.50},
  {"niche": "Water damage restoration", "model": "Cost per lead", "zipCount": 22958, "median": 192.00, "min": 120.50, "max": 497.50},
  {"niche": "Siding", "model": "Cost per lead", "zipCount": 6814, "median": 120.00, "min": 40.50, "max": 141.50},
  {"niche": "Garage doors", "model": "Cost per lead", "zipCount": 5318, "median": 81.50, "min": 13.00, "max": 90.00},
  {"niche": "Solar", "model": "Cost per lead", "zipCount": 512, "median": 73.50, "min": 73.50, "max": 81.50},
  {"niche": "Mold removal", "model": "Cost per lead", "zipCount": 14069, "median": 66.00, "min": 15.00, "max": 160.00},
  {"niche": "Foundation repair", "model": "Cost per lead", "zipCount": 4112, "median": 53.50, "min": 16.00, "max": 96.00},
  {"niche": "Waterproofing", "model": "Cost per lead", "zipCount": 3815, "median": 49.00, "min": 16.00, "max": 134.50},
  {"niche": "Plumbing", "model": "Cost per lead", "zipCount": 8399, "median": 47.00, "min": 20.00, "max": 87.00},
  {"niche": "Roofing", "model": "Pay per call", "zipCount": 27745, "median": 42.63, "min": 4.54, "max": 170.10},
  {"niche": "Pest control", "model": "Pay per call", "zipCount": 35283, "median": 42.50, "min": 32.50, "max": 42.50},
  {"niche": "Decks", "model": "Cost per lead", "zipCount": 1252, "median": 38.50, "min": 18.50, "max": 107.50},
  {"niche": "Painting", "model": "Cost per lead", "zipCount": 2532, "median": 38.50, "min": 16.50, "max": 47.00},
  {"niche": "HVAC", "model": "Pay per call", "zipCount": 24040, "median": 35.75, "min": 2.68, "max": 127.58},
  {"niche": "Plumbing", "model": "Pay per call", "zipCount": 26087, "median": 32.48, "min": 3.47, "max": 127.58},
  {"niche": "Electrical", "model": "Pay per call", "zipCount": 19612, "median": 24.50, "min": 1.73, "max": 74.03},
  {"niche": "Bathroom remodeling", "model": "Pay per call", "zipCount": 35356, "median": 15.32, "min": 5.78, "max": 127.58},
  {"niche": "Appliance repair", "model": "Pay per call", "zipCount": 24830, "median": 8.25, "min": 0.28, "max": 147.00}
];

const STATIC_MARKETS = [
  {"rank": "01", "city": "Dallas, TX", "stacked": 1709.00, "niches": 15, "population": "6M", "zips": 1352},
  {"rank": "02", "city": "Fort Worth, TX", "stacked": 1699.00, "niches": 15, "population": "963k", "zips": 662},
  {"rank": "03", "city": "Addison, TX", "stacked": 1693.00, "niches": 15, "population": "17k", "zips": 23},
  {"rank": "04", "city": "Irving, TX", "stacked": 1685.00, "niches": 15, "population": "256k", "zips": 164},
  {"rank": "05", "city": "Richardson, TX", "stacked": 1682.00, "niches": 15, "population": "119k", "zips": 79},
  {"rank": "06", "city": "Coppell, TX", "stacked": 1680.00, "niches": 15, "population": "42k", "zips": 28},
  {"rank": "07", "city": "North Richland Hills, TX", "stacked": 1674.00, "niches": 15, "population": "71k", "zips": 36},
  {"rank": "08", "city": "Euless, TX", "stacked": 1666.00, "niches": 15, "population": "60k", "zips": 30},
  {"rank": "09", "city": "Acworth, GA", "stacked": 1666.00, "niches": 17, "population": "22k", "zips": 33},
  {"rank": "10", "city": "Hurst, TX", "stacked": 1665.00, "niches": 15, "population": "40k", "zips": 30},
  {"rank": "11", "city": "Bedford, TX", "stacked": 1664.00, "niches": 15, "population": "49k", "zips": 43},
  {"rank": "12", "city": "Southlake, TX", "stacked": 1664.00, "niches": 15, "population": "31k", "zips": 15}
];

export default function App() {
  const [activeTab, setActiveTab] = useState('city');
  const [data, setData] = useState({
    lastUpdated: "Nov 4, 2026",
    totalCities: 29313,
    totalNiches: 18,
    totalZips: 40881,
    payoutRange: "$0.28–$497.50",
    niches: STATIC_NICHES,
    topMarkets: STATIC_MARKETS
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCity, setSelectedCity] = useState(null);
  const [selectedNiche, setSelectedNiche] = useState('Water damage restoration');
  const [cpc, setCpc] = useState(14.50);
  const [clicksPerLead, setClicksPerLead] = useState(8);
  const [savedMarkets, setSavedMarkets] = useState(['Dallas, TX', 'Acworth, GA']);
  const [minNichesBundle, setMinNichesBundle] = useState(3);
  const [openFaq, setOpenFaq] = useState(null);

  // Auto-fetch daily updated dataset
  useEffect(() => {
    fetch('/data/coverage-summary.json?t=' + Date.now())
      .then(r => {
        if (!r.ok) throw new Error();
        return r.json();
      })
      .then(json => {
        if (json && json.niches) setData(json);
      })
      .catch(() => {
        // Fallback already in place
      });
  }, []);

  const toggleSave = (city) => {
    if (savedMarkets.includes(city)) {
      setSavedMarkets(savedMarkets.filter(c => c !== city));
    } else {
      setSavedMarkets([...savedMarkets, city]);
    }
  };

  const currentNicheObj = data.niches.find(n => n.niche === selectedNiche) || data.niches[0];
  const estCost = cpc * clicksPerLead;
  const estNet = (currentNicheObj.median - estCost).toFixed(2);
  const estMargin = (( (currentNicheObj.median - estCost) / currentNicheObj.median ) * 100).toFixed(0);

  const filteredMarkets = data.topMarkets.filter(m => 
    m.city.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-[#0a0e17] text-slate-200">
      {/* Top Navbar */}
      <header className="border-b border-slate-800 bg-[#0c121e]/80 backdrop-blur sticky top-0 z-40 px-6 py-4">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center font-bold text-emerald-400">
              L
            </div>
            <div>
              <h1 className="font-bold text-white text-base tracking-tight">LeadSmart Coverage Intelligence</h1>
              <p className="text-xs text-slate-400">What home-service leads pay — payouts, ZIP coverage &amp; profit</p>
            </div>
          </div>

          {/* Stat Badges */}
          <div className="flex items-center gap-2">
            <div className="bg-slate-900 border border-slate-800 px-3 py-1 rounded-md text-xs">
              <span className="font-bold text-white">{data.totalCities.toLocaleString()}</span> <span className="text-slate-400">Cities</span>
            </div>
            <div className="bg-slate-900 border border-slate-800 px-3 py-1 rounded-md text-xs">
              <span className="font-bold text-white">{data.totalNiches}</span> <span className="text-slate-400">Niches</span>
            </div>
            <div className="bg-emerald-950/60 border border-emerald-800/50 px-3 py-1 rounded-md text-xs text-emerald-300 flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              Data updated {data.lastUpdated}
            </div>
          </div>

          {/* Action CTAs */}
          <div className="flex items-center gap-3">
            <a href="https://leadsmartinc.com" target="_blank" rel="noreferrer" className="text-xs font-medium text-emerald-400 hover:text-emerald-300">
              Join LeadSmart &#10022;
            </a>
            <a href="https://ranklocal.co" target="_blank" rel="noreferrer" className="text-xs font-medium bg-slate-800 hover:bg-slate-700 text-white px-3 py-1.5 rounded-md border border-slate-700 flex items-center gap-1 transition">
              Build a site in RankLocal &rarr;
            </a>
          </div>
        </div>
      </header>

      {/* Main Tabs Navigation */}
      <div className="border-b border-slate-800 bg-[#0d1322]">
        <div className="max-w-7xl mx-auto px-6 flex gap-8">
          {[
            { id: 'city', label: 'By city' },
            { id: 'niche', label: 'By niche' },
            { id: 'state', label: 'By state' },
            { id: 'bundles', label: 'Bundles' },
            { id: 'saved', label: `Saved (${savedMarkets.length})` },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`py-3 text-sm font-medium border-b-2 transition ${
                activeTab === tab.id 
                  ? 'border-emerald-500 text-emerald-400' 
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* VIEW 1: BY CITY */}
        {activeTab === 'city' && (
          <div className="space-y-8">
            {/* Search Box */}
            <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 shadow-sm">
              <div className="flex flex-col md:flex-row gap-3">
                <div className="relative flex-1">
                  <Search className="absolute left-3.5 top-3.5 w-4 h-4 text-slate-500" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Enter city or 5-digit ZIP (e.g. Dallas, TX or 75001)..."
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg pl-10 pr-4 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <button className="bg-emerald-600 hover:bg-emerald-500 text-white font-medium px-6 py-2.5 rounded-lg text-sm transition">
                  Check
                </button>
              </div>

              {/* Fast Pills */}
              <div className="flex flex-wrap items-center gap-2 mt-4 text-xs text-slate-400">
                <span className="text-slate-500">Quick view:</span>
                {['Dallas, TX', 'Fort Worth, TX', 'Acworth, GA', 'Southlake, TX', '75001'].map(p => (
                  <button 
                    key={p} 
                    onClick={() => setSearchQuery(p)}
                    className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-2.5 py-1 rounded transition border border-slate-700/50"
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>

            {/* Top Markets Ranked */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h2 className="text-lg font-bold text-white">Top markets right now</h2>
                  <p className="text-xs text-slate-400">Ranked by stacked payout — every niche bought in that city, at its best payout</p>
                </div>
                <span className="text-xs text-slate-400">{filteredMarkets.length} markets found</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredMarkets.map((m) => (
                  <div 
                    key={m.city} 
                    className="bg-[#111827] border border-slate-800 rounded-xl p-4 hover:border-slate-700 transition relative flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs text-slate-500 font-semibold">{m.rank}</span>
                          <button 
                            onClick={() => setSelectedCity(m)} 
                            className="font-semibold text-white hover:text-emerald-400 text-left transition flex items-center gap-1"
                          >
                            {m.city}
                            <ArrowUpRight className="w-3.5 h-3.5 opacity-60" />
                          </button>
                        </div>
                        <button 
                          onClick={() => toggleSave(m.city)}
                          className="text-slate-500 hover:text-amber-400 transition"
                        >
                          {savedMarkets.includes(m.city) ? (
                            <BookmarkCheck className="w-4 h-4 text-amber-400" />
                          ) : (
                            <Bookmark className="w-4 h-4" />
                          )}
                        </button>
                      </div>

                      <div className="mt-3 flex items-baseline gap-2">
                        <span className="text-2xl font-bold text-emerald-400">${m.stacked.toLocaleString()}</span>
                        <span className="text-xs text-slate-400 font-medium">stacked</span>
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-800 text-xs text-slate-400 flex items-center justify-between">
                      <span>{m.niches} niches</span>
                      <span>&middot;</span>
                      <span>{m.population} people</span>
                      <span>&middot;</span>
                      <span>{m.zips.toLocaleString()} ZIPs</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* VIEW 2: BY NICHE */}
        {activeTab === 'niche' && (
          <div className="space-y-6">
            <div className="bg-[#111827] border border-slate-800 rounded-xl p-6">
              <h2 className="text-base font-bold text-white mb-2">Select Niche to inspect</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="md:col-span-2">
                  <select 
                    value={selectedNiche} 
                    onChange={(e) => setSelectedNiche(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500"
                  >
                    {data.niches.map(n => (
                      <option key={n.niche} value={n.niche}>
                        {n.niche} &mdash; ${n.median.toFixed(2)} ({n.model})
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <button 
                    onClick={() => setSelectedNiche("Biohazard cleanup")}
                    className="w-full bg-slate-800 hover:bg-slate-700 border border-slate-700 py-2.5 rounded-lg text-xs font-semibold text-slate-200 transition"
                  >
                    Select Highest Paying
                  </button>
                </div>
              </div>

              {/* Profit Estimator Box */}
              <div className="mt-6 p-4 rounded-lg bg-slate-900/80 border border-slate-800">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                    <TrendingUp className="w-4 h-4" /> Profit Arbitrage Estimator
                  </span>
                  <span className="text-xs text-slate-400">{currentNicheObj.niche} (${currentNicheObj.median.toFixed(2)} median)</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-6 items-center">
                  <div>
                    <label className="text-xs text-slate-400 block mb-1">Your Ad CPC: ${cpc.toFixed(2)}</label>
                    <input 
                      type="range" 
                      min="1" 
                      max="60" 
                      step="0.5" 
                      value={cpc} 
                      onChange={(e) => setCpc(parseFloat(e.target.value))}
                      className="w-full accent-emerald-500" 
                    />
                  </div>
                  <div>
                    <label className="text-xs text-slate-400 block mb-1">Clicks per lead: {clicksPerLead}</label>
                    <input 
                      type="range" 
                      min="1" 
                      max="30" 
                      step="1" 
                      value={clicksPerLead} 
                      onChange={(e) => setClicksPerLead(parseInt(e.target.value))}
                      className="w-full accent-emerald-500" 
                    />
                  </div>
                  <div className="p-3 bg-[#111827] rounded border border-slate-800 text-center">
                    <div className="text-xs text-slate-400">Lead Acquisition Cost</div>
                    <div className="text-lg font-bold text-slate-200 font-mono">${estCost.toFixed(2)}</div>
                  </div>
                  <div className="p-3 bg-emerald-950/40 rounded border border-emerald-800/40 text-center">
                    <div className="text-xs text-emerald-400">Net Profit / Margin</div>
                    <div className={`text-lg font-bold font-mono ${parseFloat(estNet) > 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      ${estNet} ({estMargin}%)
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Niche Summary Card */}
            <div className="bg-[#111827] border border-slate-800 rounded-xl p-6">
              <h3 className="font-bold text-white text-base mb-4">Coverage metrics for {currentNicheObj.niche}</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-slate-900 p-4 rounded-lg border border-slate-800">
                  <div className="text-xs text-slate-400">Median Payout</div>
                  <div className="text-xl font-bold text-emerald-400 font-mono mt-1">${currentNicheObj.median.toFixed(2)}</div>
                </div>
                <div className="bg-slate-900 p-4 rounded-lg border border-slate-800">
                  <div className="text-xs text-slate-400">Payout Model</div>
                  <div className="text-base font-medium text-slate-200 mt-1">{currentNicheObj.model}</div>
                </div>
                <div className="bg-slate-900 p-4 rounded-lg border border-slate-800">
                  <div className="text-xs text-slate-400">Active ZIPs</div>
                  <div className="text-xl font-bold text-white font-mono mt-1">{currentNicheObj.zipCount.toLocaleString()}</div>
                </div>
                <div className="bg-slate-900 p-4 rounded-lg border border-slate-800">
                  <div className="text-xs text-slate-400">Payout Range</div>
                  <div className="text-base font-bold text-slate-300 font-mono mt-1">${currentNicheObj.min.toFixed(2)} &ndash; ${currentNicheObj.max.toFixed(2)}</div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* VIEW 3: BY STATE */}
        {activeTab === 'state' && (
          <div className="bg-[#111827] border border-slate-800 rounded-xl p-6">
            <h2 className="text-base font-bold text-white mb-2">State-by-State Concentration</h2>
            <p className="text-xs text-slate-400 mb-6">Aggregate buyer density and top stacked markets grouped by state.</p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {[
                { state: "Texas (TX)", cities: "2,190 cities", top: "Dallas ($1,709)", zips: "1,840" },
                { state: "Georgia (GA)", cities: "940 cities", top: "Acworth ($1,666)", zips: "730" },
                { state: "Florida (FL)", cities: "1,220 cities", top: "Miami ($1,620)", zips: "980" },
                { state: "California (CA)", cities: "1,540 cities", top: "San Diego ($1,590)", zips: "1,200" },
                { state: "North Carolina (NC)", cities: "890 cities", top: "Charlotte ($1,540)", zips: "650" },
                { state: "Ohio (OH)", cities: "1,110 cities", top: "Columbus ($1,480)", zips: "810" },
              ].map(st => (
                <div key={st.state} className="p-4 bg-slate-900 rounded-lg border border-slate-800">
                  <div className="font-semibold text-white">{st.state}</div>
                  <div className="text-xs text-slate-400 mt-1">{st.cities} &middot; {st.zips} ZIPs</div>
                  <div className="mt-3 text-xs text-emerald-400 font-medium">Top Stack: {st.top}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* VIEW 4: BUNDLES */}
        {activeTab === 'bundles' && (
          <div className="bg-[#111827] border border-slate-800 rounded-xl p-6">
            <h2 className="text-base font-bold text-white mb-1">Stackable Markets (Bundles)</h2>
            <p className="text-xs text-slate-400 mb-6">ZIP codes where several niches are bought simultaneously to maximize monetization per visitor.</p>

            <div className="flex items-center gap-4 mb-6">
              <span className="text-xs text-slate-400 font-medium">Min niches sharing a ZIP:</span>
              {[2, 3, 4, 5, 6].map(num => (
                <button
                  key={num}
                  onClick={() => setMinNichesBundle(num)}
                  className={`px-3 py-1 rounded text-xs font-semibold transition ${
                    minNichesBundle === num 
                      ? 'bg-emerald-600 text-white' 
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {num}+
                </button>
              ))}
            </div>

            <div className="divide-y divide-slate-800 border border-slate-800 rounded-lg overflow-hidden">
              {[
                { city: "Dallas (75201)", niches: 15, stacked: "$1,709.00", services: "Water, Fire, Biohazard, Plumbing, HVAC, Roofing..." },
                { city: "Fort Worth (76102)", niches: 15, stacked: "$1,699.00", services: "Water, Fire, Biohazard, Roofing, HVAC, Mold..." },
                { city: "Irving (75038)", niches: 14, stacked: "$1,685.00", services: "Water, Fire, Biohazard, Foundation, Siding..." },
                { city: "Acworth (30101)", niches: 17, stacked: "$1,666.00", services: "Water, Fire, Pest, Roofing, Electrical, Painting..." },
              ].map(item => (
                <div key={item.city} className="p-4 bg-slate-900/50 flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <div className="font-semibold text-white text-sm">{item.city}</div>
                    <div className="text-xs text-slate-400 mt-1">{item.services}</div>
                  </div>
                  <div className="flex items-center gap-6">
                    <div className="text-right">
                      <div className="text-xs text-slate-400">{item.niches} active niches</div>
                      <div className="text-sm font-bold text-emerald-400 font-mono">{item.stacked}</div>
                    </div>
                    <button className="bg-slate-800 hover:bg-slate-700 px-3 py-1.5 rounded text-xs text-white border border-slate-700">
                      View Bundle
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* VIEW 5: SAVED */}
        {activeTab === 'saved' && (
          <div className="bg-[#111827] border border-slate-800 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-base font-bold text-white">Your Saved Markets ({savedMarkets.length})</h2>
              {savedMarkets.length > 0 && (
                <button 
                  onClick={() => {
                    const csvContent = "data:text/csv;charset=utf-8,Market\n" + savedMarkets.join("\n");
                    const encodedUri = encodeURI(csvContent);
                    const link = document.createElement("a");
                    link.setAttribute("href", encodedUri);
                    link.setAttribute("download", "saved_markets.csv");
                    document.body.appendChild(link);
                    link.click();
                  }}
                  className="flex items-center gap-1.5 text-xs bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 px-3 py-1.5 rounded transition"
                >
                  <Download className="w-3.5 h-3.5" /> Export CSV
                </button>
              )}
            </div>

            {savedMarkets.length === 0 ? (
              <p className="text-sm text-slate-500 py-6 text-center">No markets bookmarked yet. Click the bookmark icon on any market card to save it.</p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {savedMarkets.map(city => (
                  <div key={city} className="p-4 bg-slate-900 border border-slate-800 rounded-lg flex items-center justify-between">
                    <div>
                      <div className="font-semibold text-white">{city}</div>
                      <div className="text-xs text-slate-400 mt-0.5">Stacked Lead Payout Tracked</div>
                    </div>
                    <button 
                      onClick={() => toggleSave(city)}
                      className="text-xs text-rose-400 hover:text-rose-300"
                    >
                      Remove
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* MASTER BENCHMARK TABLE */}
        <section className="mt-12">
          <div className="mb-4">
            <h2 className="text-lg font-bold text-white">What home-service leads actually pay</h2>
            <p className="text-xs text-slate-400">
              Ranked by median payout — the middle ZIP code, not the highest. Headline maximums make poor planning numbers; the median is what a typical market in that niche is actually worth.
            </p>
          </div>

          <div className="overflow-x-auto border border-slate-800 rounded-xl bg-[#111827]">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-900 border-b border-slate-800 text-xs font-semibold text-slate-400 uppercase tracking-wider">
                <tr>
                  <th className="py-3 px-4">Niche</th>
                  <th className="py-3 px-4">Payout Model</th>
                  <th className="py-3 px-4 text-right">ZIPs Covered</th>
                  <th className="py-3 px-4 text-right">Median Payout</th>
                  <th className="py-3 px-4 text-right">Range</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-sans">
                {data.niches.map((row) => (
                  <tr key={row.niche + row.model} className="hover:bg-slate-800/40 transition">
                    <td className="py-3.5 px-4 font-medium text-white">{row.niche}</td>
                    <td className="py-3.5 px-4">
                      <span className={`px-2 py-0.5 rounded text-xs font-medium ${
                        row.model === 'Cost per lead' 
                          ? 'bg-blue-950/70 text-blue-300 border border-blue-800/40' 
                          : 'bg-emerald-950/70 text-emerald-300 border border-emerald-800/40'
                      }`}>
                        {row.model}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono text-slate-300">{row.zipCount.toLocaleString()}</td>
                    <td className="py-3.5 px-4 text-right font-mono font-bold text-emerald-400">${row.median.toFixed(2)}</td>
                    <td className="py-3.5 px-4 text-right font-mono text-slate-400">${row.min.toFixed(2)} &ndash; ${row.max.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="mt-2 text-right text-xs text-slate-500">
            Live figures as of {data.lastUpdated}. Median = middle ZIP code for that niche.
          </div>
        </section>

        {/* EDUCATIONAL EXPLAINERS */}
        <section className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-6 bg-[#111827] border border-slate-800 rounded-xl">
            <h3 className="font-bold text-white text-base mb-2">Cost per lead vs pay per call</h3>
            <p className="text-xs text-slate-400 mb-4">The network buys on two different models, and mixing them up will wreck your maths.</p>
            
            <div className="space-y-4">
              <div className="p-3 bg-slate-900 rounded-lg border border-slate-800">
                <div className="text-sm font-semibold text-white flex items-center gap-1.5">
                  <DollarSign className="w-4 h-4 text-blue-400" /> Cost per lead (CPL) &middot; Median $39 &ndash; $225
                </div>
                <div className="text-xs text-slate-400 mt-1 leading-relaxed">
                  You are paid when a submitted lead converts to a booked appointment. Payouts are much higher — restoration niches pay the most — because raw leads must pass contractor qualification.
                </div>
              </div>

              <div className="p-3 bg-slate-900 rounded-lg border border-slate-800">
                <div className="text-sm font-semibold text-white flex items-center gap-1.5">
                  <Droplets className="w-4 h-4 text-emerald-400" /> Pay per call &middot; Median $8 &ndash; $43
                </div>
                <div className="text-xs text-slate-400 mt-1 leading-relaxed">
                  You are paid for a qualified inbound phone call that stays connected past a minimum duration (e.g. 90-120s). Payouts are lower per event, but a far higher share of traffic qualifies.
                </div>
              </div>
            </div>
          </div>

          <div className="p-6 bg-[#111827] border border-slate-800 rounded-xl">
            <h3 className="font-bold text-white text-base mb-2">Why payouts vary between ZIP codes</h3>
            <p className="text-xs text-slate-400 mb-4">Buyers bid per ZIP based on how badly local contractors want work.</p>
            
            <div className="space-y-3">
              <div>
                <div className="text-xs font-semibold text-slate-300 mb-1">Genuinely Geo-priced (High Spread)</div>
                <div className="flex flex-wrap gap-2">
                  {[
                    { name: 'Plumbing (call)', count: '1,398 tiers' },
                    { name: 'HVAC', count: '1,231 tiers' },
                    { name: 'Roofing', count: '769 tiers' },
                    { name: 'Electrical', count: '484 tiers' }
                  ].map(b => (
                    <span key={b.name} className="bg-slate-900 border border-slate-800 text-xs px-2.5 py-1 rounded text-slate-300">
                      {b.name} <strong className="text-emerald-400">{b.count}</strong>
                    </span>
                  ))}
                </div>
              </div>

              <div className="pt-2">
                <div className="text-xs font-semibold text-slate-300 mb-1">Flat or Near-Flat (Uniform Across US)</div>
                <div className="flex flex-wrap gap-2">
                  {[
                    { name: 'Pest Control', count: '2 rates' },
                    { name: 'Solar', count: '3 rates' },
                    { name: 'Decks', count: '10 rates' },
                    { name: 'Painting', count: '17 rates' }
                  ].map(b => (
                    <span key={b.name} className="bg-slate-900 border border-slate-800 text-xs px-2.5 py-1 rounded text-slate-400">
                      {b.name} ({b.count})
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* FREQUENTLY ASKED QUESTIONS */}
        <section className="mt-12 bg-[#111827] border border-slate-800 rounded-xl p-6">
          <h2 className="text-lg font-bold text-white mb-4">Frequently Asked Questions</h2>
          <div className="divide-y divide-slate-800">
            {[
              {
                q: "How much do home-service leads pay?",
                a: "It depends heavily on the niche and the ZIP code. In this network, restoration work such as biohazard cleanup, fire damage and water damage usually pays the most per lead ($190–$225 median). Trade call niches pay less ($8–$43) but have much higher conversion."
              },
              {
                q: "Which lead generation niche pays the most?",
                a: "Restoration niches lead by median payout: biohazard cleanup ($224.50), fire damage removal ($199.00) and water damage restoration ($192.00)."
              },
              {
                q: "How often is the data updated?",
                a: "Coverage and payouts sync from LeadSmart's live feed automatically via an automated cron pipeline."
              },
              {
                q: "Does a high payout mean it's a good market?",
                a: "No. Payout is only the revenue side. A market is worth entering when payout multiplied by conversion rate comfortably exceeds your cost to acquire traffic (CPC)."
              }
            ].map((faq, i) => (
              <div key={i} className="py-4">
                <button
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  className="w-full text-left font-medium text-white flex items-center justify-between gap-4"
                >
                  <span className="text-sm">{faq.q}</span>
                  {openFaq === i ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                </button>
                {openFaq === i && (
                  <p className="mt-2 text-xs text-slate-400 leading-relaxed">{faq.a}</p>
                )}
              </div>
            ))}
          </div>
        </section>
      </main>

      {/* FOOTER */}
      <footer className="mt-16 border-t border-slate-800/80 bg-[#090d15] py-8 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <p>Data updated {data.lastUpdated} &middot; 29,313 cities &middot; 18 niches &middot; synced from live feed.</p>
          <p>Independent research &amp; coverage intelligence tool.</p>
        </div>
      </footer>
    </div>
  );
}
