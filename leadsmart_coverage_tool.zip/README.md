# LeadSmart Coverage Intelligence

100% authentic standalone web replica of the LeadSmart Coverage Intelligence platform (leadsmart-coverage.netlify.app).

## Features
- **By city**: City and ZIP search with stacked payout calculations and city detail breakdown.
- **By niche**: Multi-parameter search with real-time **Profit Estimator** (CPC, Clicks/lead, Net margin & ROI).
- **By state**: State-level market aggregation.
- **Bundles**: Multi-niche stackable market discovery.
- **Saved**: LocalStorage bookmarking & CSV exporter.
- **Automated Daily Sync**: Python sync pipeline (`sync.py`) and GitHub Action workflow.

## Running Locally

1. Install dependencies:
   ```bash
   npm install
   ```

2. Start development server:
   ```bash
   npm run dev
   ```

3. Open your browser at `http://localhost:5173`.
